package com.helloWorld.helloWorld;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
public class CustomerController {

    @PostMapping(path="/customers", consumes = "text/plain")
    @ResponseBody
    public String greetingsByQueryPost(@RequestBody String userString, @RequestParam String type) {
        ObjectMapper mapper = new ObjectMapper();
        mapper.enable(DeserializationFeature.UNWRAP_ROOT_VALUE);
        ObjectReader objectReader = mapper.reader(new TypeReference<List<Customer>>() {}).withRootName("customers");

        String match = "";
        try {
            List<Customer> customers = objectReader.readValue(userString);
            match = type+" customers are:\n";
            for (Customer c: customers) {
                if (c.getAccountType().equals(type)){
                    match+=c.getName()+"\n";
                }
            }
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return match;

    }
}
