package com.helloWorld.helloWorld;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.awt.*;

@RestController
public class GreetingsController {

    @GetMapping(path="/greetings/{name}")
    @ResponseBody
    public String greet(@PathVariable String name){
        return "Hello "+ name+"!";
    }

    @GetMapping(path="/greetingsByQueryParam")
    @ResponseBody
    public String greetingsByQueryParam(@RequestParam String name){
        return "Hello "+ name+"!";
    }


    @PostMapping(path="/greetingsByQueryPost", consumes = "text/plain")
    @ResponseBody
    public String greetingsByQueryPost(@RequestBody String userString) {
        ObjectMapper mapper = new ObjectMapper();
        mapper.enable(DeserializationFeature.UNWRAP_ROOT_VALUE);
        User user = null;
        try {
            user = mapper.readValue(userString, User.class);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return "Greetings "+user.getName()+ " from "+user.getDepartment()+" department!";

    }
}
