package com.helloWorld.helloWorld;

public class Customer {
    private String name,accountType;

    public Customer(String name, String accountType) {
        this.name = name;
        this.accountType = accountType;
    }

    public Customer(){

    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAccountType() {
        return this.accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }
}
